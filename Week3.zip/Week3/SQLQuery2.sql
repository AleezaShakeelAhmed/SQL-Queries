CREATE DATABASE northwind

/* Query # 1 */
CREATE TABLE Student(
	RegNo Varchar(20),
	FirstName Varchar(20),
	LastName Varchar(20),
	GPA float,
	Contact int,
	);

/* Query # 2 */
insert into Student values('2021CS1','Syed Hashir','Hussnain',4.0,38776)
insert into Student values('2021CS2','Shahzaib','Rafi',3.9,3876)
insert into Student values('2021CS3','Shakeel','Ahmed',0.0,38774)
insert into Student values('2021CS4','Kabir','Khan',0.0,38648)
insert into Student values('2021CS6','Mahnoor','Fatima',3.6,38782)

/* Query # 3 */
SELECT *
FROM Student;

/* Query # 4 */
SELECT FirstName,GPA
FROM Student;

/* Query # 5 */
SELECT *
FROM Student
WHERE GPA>3.5;

/* Query # 6 */
SELECT *
FROM Student
WHERE GPA<=3.5;

/* Query # 7 */
SELECT concat(FirstName,' ',LastName)
FROM Student;



