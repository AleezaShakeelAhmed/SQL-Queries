	/* Query # 1 */
SELECT OrderID
FROM Orders
WHERE ShippedDate>RequiredDate;

/* Query # 2 */
SELECT  DISTINCT Country
FROM Employees;

/* Query # 3 */
SELECT *
FROM Employees
WHERE Region is null or ReportsTo is null;

/* Query # 4 */
SELECT ProductName
From Products
WHERE Discontinued=1

/* Query # 5 */
SELECT OrderID
FROM [Order Details]
WHERE Discount =0;

/* Query # 6 */
SELECT CustomerID
FROM Customers
Where Region is NULL;

/* Query # 7 */
SELECT CustomerID,Phone
FROM Customers
Where Country = 'UK'or Country = 'USA' ;

/* Query # 8 */
SELECT CompanyName
FROM Suppliers
WHERE HomePage is not Null;

/* Query # 9 */
SELECT Distinct ShipCountry
FROM orders
WHERE YEAR(ShippedDate)=1997;

/* Query # 10 */
SELECT CustomerID
FROM orders
WHERE ShippedDate is Null;

/* Query # 11 */
SELECT SupplierID,CompanyName,City
FROM Suppliers

/* Query # 12 */
SELECT *
FROM Employees
WHERE City='LONDON' ;
/* Query # 13 */
SELECT *
FROM Products
WHERE Discontinued =0 ;

/* Query # 14 */
SELECT OrderID
FROM [Order Details]
WHERE Discount<=0.1 ;

/* Query # 15 */
SELECT EmployeeID,FirstName,HomePhone
FROM Employees
WHERE Region�is�null�;