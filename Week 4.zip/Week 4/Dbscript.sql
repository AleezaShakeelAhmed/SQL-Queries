/* Query # 1 */
SELECT ProductName
FROM Products
WHERE UnitPrice>(SELECT AVG(UnitPrice)
				 FROM Products);
/* Query # 2 */
SELECT OrderDate,COUNT(OrderID) AS NumberofOrders
FROM Orders
GROUP BY OrderDate;

/* Query # 3 */
SELECT ShipCountry,ShipVia
FROM Orders
WHERE ShipVia>=2;

/* Query # 4 */
SELECT MONTH(order_date) AS Month_Number, COUNT(*) AS Orders_Delayed
FROM orders
WHERE ship_date > order_date
GROUP BY Month_Number


/* Query # 5 */
SELECT order_id AS OrderID, SUM(discount) AS Discount
FROM order_details
GROUP BY order_id
HAVING SUM(discount) > 0

/* Query # 6 */
SELECT ship_city AS City, COUNT(*) AS Num_Orders
FROM orders
WHERE ship_country = 'USA' AND YEAR(ship_date) = 1997
GROUP BY ship_city

/* Query # 7 */
SELECT ship_country AS Country, COUNT(*) AS Orders_Delayed
FROM orders
WHERE ship_date > order_date
GROUP BY Country

/* Query # 8 */
SELECT order_id AS OrderID, SUM(unit_price * quantity) AS Total_Price, SUM(discount) AS Total_Discount
FROM order_details
GROUP BY order_id
HAVING SUM(discount) > 0

/* Query # 9 */
SELECT e.region AS Region, o.ship_city AS City, COUNT(*) AS Num_Orders
FROM orders o
JOIN employees e ON o.employee_id = e.employee_id
WHERE o.ship_country = 'USA' AND YEAR(o.ship_date) = 1997
GROUP BY e.region, o.ship_city


