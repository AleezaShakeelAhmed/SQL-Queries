	/* Question # 1 */
	/* Query # 1 */
	SELECT AVG(ReportsTo)
	FROM Employees
	GROUP BY TitleOfCourtesy;

	/* Query # 2 */
	SELECT MIN(EmployeeID)As EmployeeID,MIN(Extension) as Extension
	FROM Employees
	GROUP BY TitleOfCourtesy;

	/* Query # 3 */
	SELECT SUM(EmployeeID)As EmployeeID
	FROM Employees
	GROUP BY TitleOfCourtesy;

	/* Query # 4 */
	SELECT COUNT(Extension) AS Extension
	FROM Employees
	GROUP BY Title;

	/* Query # 5 */
	SELECT STDEV(EmployeeID)As EmployeeID
	FROM Employees
	GROUP BY Title;

	/* Query # 6 */
	SELECT STDEVP(ReportsTo) as ReportsTo
	FROM Employees
	GROUP BY Title;

	/* Query # 7 */
	SELECT VAR(ReportsTo) as ReportsTo
	FROM Employees
	GROUP BY Title;

	/* Query # 8 */
	SELECT VARP(ReportsTo) as ReportsTo
	FROM Employees
	GROUP BY TitleOfCourtesy;

	/* Query # 9 */
	SELECT MAX(EmployeeID)As EmployeeID,MAX(Extension) as Extension
	FROM Employees
	GROUP BY TitleOfCourtesy;

	
	/* Question # 2 */
	/* Query # 1 */
	SELECT AVG(ReportsTo)
	FROM Employees
	GROUP BY TitleOfCourtesy
	HAVING AVG(ReportsTo)>2;

	/* Query # 2 */
	SELECT MIN(EmployeeID)As EmployeeID,MIN(Extension) as Extension
	FROM Employees
	GROUP BY TitleOfCourtesy
	HAVING MIN(EmployeeID)>1;

	/* Query # 3 */
	SELECT SUM(EmployeeID)As EmployeeID
	FROM Employees
	GROUP BY TitleOfCourtesy
	HAVING SUM(EmployeeID)>5;

	/* Query # 4 */
	SELECT COUNT(Extension) AS Extension
	FROM Employees
	GROUP BY Title
	HAVING COUNT(Extension)>1;

	/* Query # 5 */
	SELECT STDEV(EmployeeID)As EmployeeID
	FROM Employees
	GROUP BY Title
	HAVING STDEV(EmployeeID)<10;

	/* Query # 6 */
	SELECT STDEVP(ReportsTo) as ReportsTo
	FROM Employees
	GROUP BY Title
	HAVING STDEVP(ReportsTo)>0;

	/* Query # 7 */
	SELECT VAR(ReportsTo) as ReportsTo
	FROM Employees
	GROUP BY Title
	HAVING VAR(ReportsTo)>1;

	/* Query # 8 */
	SELECT VARP(ReportsTo) as ReportsTo
	FROM Employees
	GROUP BY TitleOfCourtesy
	HAVING VARP(ReportsTo)>1;

	/* Query # 9 */
	SELECT MAX(EmployeeID) Employee,MAX(Extension)  Ex
	FROM Employees e
	GROUP BY TitleOfCourtesy
	HAVING MAX(EmployeeID)>3;


	/* Question # 3 */
	SELECT EmployeeID As EID,Extension as E,FirstName as FT,LastName as LT
	FROM Employees;

	/* Question # 4 */
	SELECT EmployeeID EID,Extension E,FirstName FT,LastName LT
	FROM Employees AS E;