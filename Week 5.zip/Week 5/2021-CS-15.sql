/*	Queston# 1 */

/*	Cross Join*/
SELECT CompanyName
From Customers,CustomerCustomerDemo;

/*	Natural Join*/
SELECT CustomerID
From  Orders
JOIN [Order Details]
ON Orders.OrderID=[Order Details].OrderID

/*	Equi Join*/
SELECT *
FROM Orders
INNER JOIN [Order Details]
ON Orders.OrderID = [Order Details].OrderID;


/*	Inner Join*/
SELECT *
FROM Orders
INNER JOIN [Order Details]
ON Orders.OrderID = [Order Details].OrderID;

/*	Left Outer Join# 1 */
SELECT *
FROM Orders
LEFT JOIN [Order Details]
ON Orders.OrderID=[Order Details].OrderID

/*	Right Outer Join*/
SELECT *
FROM Orders
RIGHT JOIN [Order Details]
ON Orders.OrderID=[Order Details].OrderID

/*  Full Outer Join*/
SELECT *
FROM Orders
FULL OUTER JOIN [Order Details]
ON Orders.OrderID=[Order Details].OrderID



/*	Queston# 2 */
/* USING SELF JOIN*/
SELECT *
FROM Orders o1
INNER JOIN Orders o2
ON o1.orderID = o2.orderID;

/*USING CROSS PRODUCT*/
SELECT *
FROM Orders o1,Orders o2
WHERE o1.orderID = o2.orderID;


/*	Queston# 3 */
SELECT C.CustomerID, C.companyname, O.orderid, O.orderdate
FROM Customers AS C
JOIN Orders AS O
ON C.CustomerID = O.CustomerID;

/*	Queston# 4 */
SELECT Customers.CustomerID, Orders.OrderID, Orders.OrderDate
FROM Customers
LEFT OUTER JOIN Orders
ON Customers.CustomerID = Orders.CustomerID;


/*	Queston# 5 */
SELECT Customers.CustomerID, Orders.OrderID, Orders.OrderDate
FROM Customers
LEFT OUTER JOIN Orders
ON Customers.CustomerID = Orders.CustomerID
WHERE Orders.OrderID IS NULL;

/*	Queston# 6 */
SELECT Customers.CustomerID, Orders.OrderID, Orders.OrderDate
FROM Customers
INNER JOIN Orders
ON Customers.CustomerID = Orders.CustomerID
WHERE Orders.OrderDate BETWEEN '1997-07-01' AND '1997-07-31';


/*	Queston# 7 */
SELECT CustomerID,COUNT(OrderID) AS totalorders
FROM Orders
GROUP BY CustomerID

/*	Queston# 8 */
SELECT EmployeeID,FirstName,LastName,HireDate
FROM Employees

/*	Queston# 9 */
SELECT EmployeeID,HireDate
FROM Employees
WHERE HireDate BETWEEN 04-07-1996 AND 04-08-1997

/*	Queston# 10 */
 SELECT C.CustomerID,COUNT(*)Totalorders,Sum(A.quantity) Totalquantity
FROM Customers C
JOIN Orders O
ON C.CustomerID=O.CustomerID and C.Country='USA'
JOIN [Order Details]A
ON O.OrderID=A.OrderID
GROUP BY C.CustomerID

/*	Queston# 11 */
SELECT C.CustomerID,C.CompanyName,O.OrderID,O.OrderDate
FROM Customers C 
JOIN Orders O
ON C.CustomerID=O.CustomerID and OrderDate='1997-07-04'

/*	Queston# 12 */
SELECT E.FirstName  EmployeeName, YEAR(GETDATE()) - YEAR(E.BirthDate) AS Age, YEAR(GETDATE()) - YEAR(E2.BirthDate) AS ManagerAge
FROM Employees E
JOIN Employees E2
ON E.BirthDate < E2.BirthDate
WHERE  E2.Title LIKE '%Manager%'

/*	Queston# 13 */
SELECT P.ProductName,R.OrderDate
FROM Products P
JOIN [Order Details]O
ON O.ProductID=P.ProductID
JOIN Orders R
ON R.OrderID=O.OrderID
WHERE R.OrderDate = '1997-08-8'  

/*	Queston# 14 */
SELECT o.ShipAddress,O.ShipCity,O.ShipCountry
FRom Orders o
JOIN Employees E
ON O.EmployeeID=E.EmployeeID  and E.FirstName='Anne'
WHERE O.ShippedDate>O.RequiredDate 

/*	Queston# 15 */
SELECT O.ShipCountry
FROM Categories C
JOIN Products P
ON P.CategoryID=C.CategoryID and C.CategoryName= 'Beverages'
JOIN [Order Details] R
ON R.ProductID=P.ProductID
JOIN Orders O
ON O.OrderID=R.OrderID

/*	Queston# 16 */
SELECT Orders.ShipCountry
FROM Orders
JOIN [Order Details]
ON Orders.OrderID=[Order Details].OrderID
JOIN Products
ON Products.ProductID=[Order Details].ProductID
WHERE Products.ProductName='beverages'
